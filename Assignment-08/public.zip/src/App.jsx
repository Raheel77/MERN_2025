import "./App.css";
import { Container } from "react-bootstrap";

import Input from "./components/Input/Input";
import Input2 from "./components/Input2/Input2";
import Button from "./components/Button";
import Radio from "./components/Radio";
import "bootstrap/dist/css/bootstrap.min.css";
import Navigations from "./components/Navigations";
import Cards from "./components/Cards";
import { DataUrl } from "./components/Data";

let array = ["Ali", "Ahemad", "Jamsheed", "Raheel"];
function App() {
  return (
    <Container>
      <Navigations />
      <div
        style={{
          display: "flex",
          flexFlow: "wrap",
          justifyContent: "center",
          gap: 20,
        }}
      >
        {DataUrl.map((e, i) => {
          return <Cards title={e.title} url={e.url} id={e.id} />;
        })}
      </div>
    </Container>
  );
}

export default App;
