export default function Button({ text }) {
  return (
    <button class="btn-submit" type="submit">
      {text}
    </button>
  );
}
